package com.example.tablegenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView4;
    EditText editText;
    Button button;
    TextView textView;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView4 = findViewById(R.id.textView4);
        textView4.setText("Welcome to Table Generator");
        editText = findViewById(R.id.editText);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder str = new StringBuilder();
                String s1 = editText.getText().toString();
                int v1 = Integer.parseInt(s1);
                for(int i=1;i<=10;i++) {
                    str.append(v1+"*"+i+"="+(v1*i)+"\n");

                }
                textView.setText(str);
            }
        });
    }
}